

for item in 100...400 {
  if item % 2 == 0 {
    print(item)
  }
}

var initalValue = 100
while initalValue <= 400 {
  if initalValue % 2 == 0 {
    print(initalValue)
    initalValue +=1
  }
}
var initalValue2 == 100
repeat {
  print(initalValue2)
  initalValue2 +=1
} while initalValue2 <=400