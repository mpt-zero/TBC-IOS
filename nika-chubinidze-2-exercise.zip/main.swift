
for item in 10...100 {
  if item % 10 == 0 && item > 50 {
    print(item * 2)
  }
}

var initialvalue = 10
while <= 100 {
  if initalValue % 10 ==0 && initalValue > 50 {
    print(item * 2)
    initalValue +=1
  }
}

var initialvalue2 == 10
repeat{
  if initalValue2 % 10 ==0 && initalValue2 > 50 {
    print(initalValue2 * 2)
    initalValue2 +=1
  }
} while initalValue2 <=100