var arrayOfOptionals: [Int?] = [5, nil, 13, nil, nil, 3]
var newArray : [Int] = []
for item in 0..<arrayOfOptionals.count {
  if let unwrappedElements = arrayOfOptionals[item] {
    newArray.append(unwrappedElements)
}
  if arrayOfOptionals[item] == nil {
    arrayOfOptionals[item] = 0
  }
  
}

print(newArray)

// to demonstrate that nil values became 0
for item in 0..<arrayOfOptionals.count {
  if let unwrappedElements = arrayOfOptionals[item] {
    print(unwrappedElements)
  }
}  

