var variable1 : String = "Swift"
var variable2 : Int = 5
var variable3 = variable1 + " \(variable2)"
print(variable3)